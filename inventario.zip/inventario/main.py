import tkinter as tk
from tkinter import messagebox, font

from db import get_connection
from menu import crear_menu_principal

def login():
    user = entry_user.get()
    pwd = entry_pass.get()

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE usuario=%s AND clave=%s", (user, pwd))
    result = cursor.fetchone()
    conn.close()

    if result:
        messagebox.showinfo("Bienvenido", f"Acceso permitido. Rol: {result[3]}")
        ventana_login.destroy()
        crear_menu_principal(result[3])
    else:
        messagebox.showerror("Error", "Usuario o contraseña incorrecta")

# Crear ventana principal
ventana_login = tk.Tk()
ventana_login.title("Login - Sistema de Inventario")
ventana_login.geometry("350x400")
ventana_login.configure(bg="#f0f4f8")
ventana_login.resizable(False, False)

# Fuente personalizada
titulo_font = font.Font(family="Helvetica", size=22, weight="bold")
label_font = font.Font(family="Helvetica", size=12)
entry_font = font.Font(family="Helvetica", size=12)

# Frame central con padding y fondo blanco para simular tarjeta
frame_login = tk.Frame(ventana_login, bg="white", bd=2, relief="groove")
frame_login.place(relx=0.5, rely=0.5, anchor="center", width=300, height=320)

# Título
titulo = tk.Label(frame_login, text="Inicio de Sesión", bg="white", fg="#333333", font=titulo_font)
titulo.pack(pady=(30, 20))

# Etiqueta y campo usuario
label_user = tk.Label(frame_login, text="Usuario", bg="white", fg="#555555", font=label_font)
label_user.pack(anchor="w", padx=30)

entry_user = tk.Entry(frame_login, font=entry_font, bd=1, relief="solid")
entry_user.pack(padx=30, pady=(0, 15), ipady=6)

# Etiqueta y campo contraseña
label_pass = tk.Label(frame_login, text="Contraseña", bg="white", fg="#555555", font=label_font)
label_pass.pack(anchor="w", padx=30)

entry_pass = tk.Entry(frame_login, font=entry_font, bd=1, relief="solid", show="*")
entry_pass.pack(padx=30, pady=(0, 25), ipady=6)

# Botón ingresar
btn_ingresar = tk.Button(frame_login, text="Ingresar", command=login,
                         bg="#4A90E2", fg="white", font=label_font,
                         activebackground="#357ABD", activeforeground="white",
                         bd=0, relief="flat", cursor="hand2")
btn_ingresar.pack(padx=30, ipady=8)

# Efecto hover simple para el botón
def on_enter(e):
    btn_ingresar['bg'] = '#357ABD'
def on_leave(e):
    btn_ingresar['bg'] = '#4A90E2'

btn_ingresar.bind("<Enter>", on_enter)
btn_ingresar.bind("<Leave>", on_leave)

# Ejecutar ventana
ventana_login.mainloop()