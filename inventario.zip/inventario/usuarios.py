import tkinter as tk
from tkinter import messagebox, ttk
from db import get_connection

def gestionar_usuarios():
    ventana = tk.Toplevel()
    ventana.title("Gestión de Usuarios")
    ventana.geometry("600x500")
    ventana.configure(bg="#FAF3E0")
    ventana.resizable(0,0)#Asigna un valor booleano 'Falso', bloqueando que la ventana sea redimensionada

    tk.Label(ventana, text="Administración de Usuarios", font=("Arial", 16, "bold"), bg="#FAF3E0", fg="#4A4E69").pack(pady=10)

    estilo_label = {'bg': "#FAF3E0", 'fg': "#22223B", 'font': ("Arial", 11)}
    estilo_entry = {'bg': "#FFFFFF", 'font': ("Arial", 11)}
    estilo_boton = {
        'font': ("Arial", 11),
        'bg': "#C9CCD5",
        'fg': "#22223B",
        'activebackground': "#9A8C98",
        'width': 25,
        'padx': 5,
        'pady': 5,
    }

    def cargar_usuarios():
        for row in tabla.get_children():
            tabla.delete(row)
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, usuario, rol FROM usuarios")
        for usuario in cursor.fetchall():
            tabla.insert("", "end", values=usuario)
        conn.close()

    def agregar_usuario():
        u = entry_user.get()
        c = entry_pass.get()
        r = rol_var.get()
        if u and c:
            conn = get_connection()
            cursor = conn.cursor()
            try:
                cursor.execute("INSERT INTO usuarios (usuario, clave, rol) VALUES (%s, %s, %s)", (u, c, r))
                conn.commit()
                cargar_usuarios()
                entry_user.delete(0, tk.END)
                entry_pass.delete(0, tk.END)
            except:
                messagebox.showerror("Error", "No se pudo agregar el usuario. ¿Ya existe?")
            conn.close()

    def eliminar_usuario():
        seleccionado = tabla.selection()
        if seleccionado:
            id_usuario = tabla.item(seleccionado[0])["values"][0]
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM usuarios WHERE id = %s", (id_usuario,))
            conn.commit()
            conn.close()
            cargar_usuarios()

    # Formulario
    formulario = tk.Frame(ventana, bg="#FAF3E0")
    formulario.pack(pady=10)

    tk.Label(formulario, text="Usuario:", **estilo_label).grid(row=0, column=0, sticky="e", padx=5, pady=2)
    entry_user = tk.Entry(formulario, **estilo_entry)
    entry_user.grid(row=0, column=1, padx=5, pady=2)

    tk.Label(formulario, text="Contraseña:", **estilo_label).grid(row=1, column=0, sticky="e", padx=5, pady=2)
    entry_pass = tk.Entry(formulario, show="*", **estilo_entry)
    entry_pass.grid(row=1, column=1, padx=5, pady=2)

    tk.Label(formulario, text="Rol:", **estilo_label).grid(row=2, column=0, sticky="e", padx=5, pady=2)
    rol_var = tk.StringVar(value="Vendedor")
    rol_menu = tk.OptionMenu(formulario, rol_var, "Administrador", "Vendedor")
    rol_menu.config(bg="#FFFFFF", font=("Arial", 10))
    rol_menu.grid(row=2, column=1, padx=5, pady=2)

    tk.Button(ventana, text="Agregar Usuario", command=agregar_usuario, **estilo_boton).pack(pady=5)

    # Tabla
    columnas = ("ID", "Usuario", "Rol")
    tabla = ttk.Treeview(ventana, columns=columnas, show="headings")
    for col in columnas:
        tabla.heading(col, text=col)
    tabla.pack(pady=10, fill="x", padx=20)

    tk.Button(ventana, text="Eliminar Usuario", command=eliminar_usuario, **estilo_boton).pack(pady=5)

    cargar_usuarios()