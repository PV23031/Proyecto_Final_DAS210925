from db import get_connection
import csv
import tkinter as tk
from tkinter import filedialog, messagebox

def exportar_reporte_csv(nombre_archivo=None):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM productos")
    datos = cursor.fetchall()
    conn.close()

    if not nombre_archivo:
        nombre_archivo = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if not nombre_archivo:
            return

    with open(nombre_archivo, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['ID', 'Nombre', 'Stock'])
        writer.writerows(datos)

    messagebox.showinfo("Reporte", f"Reporte guardado como {nombre_archivo}")


def ventana_exportar_reporte():
    exportar_reporte_csv()
