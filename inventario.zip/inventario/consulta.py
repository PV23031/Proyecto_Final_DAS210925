import tkinter as tk
from db import get_connection
from tkinter import ttk

def consultar_inventario():
    ventana = tk.Toplevel()
    ventana.title("Consulta de Inventario")
    ventana.geometry("500x400")
    ventana.configure(bg="#FAF3E0")

    tk.Label(ventana, text="Inventario Actual", font=("Arial", 16, "bold"), bg="#FAF3E0", fg="#4A4E69").pack(pady=10)

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT nombre, stock FROM productos")
    productos = cursor.fetchall()
    conn.close()

    tabla = ttk.Treeview(ventana, columns=("Producto", "Stock"), show="headings")
    tabla.heading("Producto", text="Producto")
    tabla.heading("Stock", text="Stock")

    for nombre, stock in productos:
        tabla.insert("", "end", values=(nombre, stock))

    tabla.pack(padx=20, pady=10, fill="both", expand=True)
