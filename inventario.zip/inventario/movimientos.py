from db import get_connection
import tkinter as tk
from tkinter import messagebox, font

def registrar_movimiento(tipo, nombre_producto, cantidad):
    conn = get_connection()
    cursor = conn.cursor()

    # Verificar si el producto existe
    cursor.execute("SELECT id, stock FROM productos WHERE nombre = %s", (nombre_producto,))
    producto = cursor.fetchone()

    if producto:
        producto_id, stock_actual = producto
        if tipo == 'entrada':
            cursor.execute("UPDATE productos SET stock = stock + %s WHERE id = %s", (cantidad, producto_id))
            conn.commit()
            messagebox.showinfo("Éxito", f"Entrada registrada para '{nombre_producto}'")
        elif tipo == 'salida':
            if stock_actual >= cantidad:
                cursor.execute("UPDATE productos SET stock = stock - %s WHERE id = %s", (cantidad, producto_id))
                conn.commit()
                messagebox.showinfo("Éxito", f"Salida registrada para '{nombre_producto}'")
            else:
                messagebox.showerror("Error", f"Stock insuficiente. Stock actual: {stock_actual}")
    else:
        if tipo == 'entrada':
            # Si no existe el producto y es entrada, lo insertamos
            cursor.execute("INSERT INTO productos (nombre, stock) VALUES (%s, %s)", (nombre_producto, cantidad))
            conn.commit()
            messagebox.showinfo("Éxito", f"Producto '{nombre_producto}' creado y entrada registrada")
        else:
            messagebox.showerror("Error", f"El producto '{nombre_producto}' no existe")

    conn.close()

def ventana_movimiento(tipo):
    ventana = tk.Toplevel()
    ventana.title(f"Registrar {tipo.capitalize()}")
    ventana.geometry("350x300")
    ventana.configure(bg="#f0f4f8")
    ventana.resizable(False, False)

    # Fuentes personalizadas
    titulo_font = font.Font(family="Helvetica", size=18, weight="bold")
    label_font = font.Font(family="Helvetica", size=12)
    entry_font = font.Font(family="Helvetica", size=12)

    # Frame "tarjeta" blanco con borde para contener los widgets
    frame = tk.Frame(ventana, bg="white", bd=2, relief="groove")
    frame.place(relx=0.5, rely=0.5, anchor="center", width=300, height=280)

    # Título
    titulo = tk.Label(frame, text=f"Registrar {tipo.capitalize()}", bg="white", fg="#333333", font=titulo_font)
    titulo.pack(pady=(20, 15))

    # Etiqueta y entrada nombre producto
    label_nombre = tk.Label(frame, text="Nombre del producto:", bg="white", fg="#555555", font=label_font)
    label_nombre.pack(anchor="w", padx=25)

    entry_nombre = tk.Entry(frame, font=entry_font, bd=1, relief="solid")
    entry_nombre.pack(padx=25, pady=(0,15), ipady=6)

    # Etiqueta y entrada cantidad
    label_cant = tk.Label(frame, text="Cantidad:", bg="white", fg="#555555", font=label_font)
    label_cant.pack(anchor="w", padx=25)

    entry_cant = tk.Entry(frame, font=entry_font, bd=1, relief="solid")
    entry_cant.pack(padx=25, pady=(0,20), ipady=6)

    # Botón registrar
    btn_registrar = tk.Button(frame, text="Registrar", bg="#4A90E2", fg="white", font=label_font,
                              activebackground="#357ABD", activeforeground="white",
                              bd=0, relief="flat", cursor="hand2")
    btn_registrar.pack(padx=25, ipady=8)

    # Función para registrar movimiento con manejo de errores
    def registrar():
        try:
            nombre = entry_nombre.get().strip()
            cant = int(entry_cant.get())
            if not nombre or cant <= 0:
                raise ValueError
            registrar_movimiento(tipo, nombre, cant)
            ventana.destroy()
        except:
            messagebox.showerror("Error", "Datos inválidos. Verifica el nombre y la cantidad.")

    btn_registrar.config(command=registrar)

    # Efecto hover simple para el botón
    def on_enter(e):
        btn_registrar['bg'] = '#357ABD'
    def on_leave(e):
        btn_registrar['bg'] = '#4A90E2'

    btn_registrar.bind("<Enter>", on_enter)
    btn_registrar.bind("<Leave>", on_leave)

    ventana.mainloop()