import tkinter as tk
from PIL import Image, ImageTk
from movimientos import ventana_movimiento
from reportes import ventana_exportar_reporte
from alertas import mostrar_alertas_ventana
from consulta import consultar_inventario
from usuarios import gestionar_usuarios

def crear_menu_principal(rol):
    menu = tk.Tk()
    menu.title("Sistema de Inventario - Menú Principal")
    menu.geometry("600x500")
    menu.resizable(0,0)#Asigna un valor booleano 'Falso', bloqueando que la ventana sea redimensionada

    # Imagen de fondo
    fondo_img = Image.open("Proyecto nuevo2.png")
    fondo_img = fondo_img.resize((600, 500))
    fondo_tk = ImageTk.PhotoImage(fondo_img)
    fondo_label = tk.Label(menu, image=fondo_tk)
    fondo_label.place(x=0, y=0, relwidth=1, relheight=1)
    fondo_label.image = fondo_tk  # evitar recolección de basura

    titulo = tk.Label(menu, text="Bienvenido al Sistema de Inventario", font=("Arial", 18, "bold"), fg="#4A4E69", bg="#FFFFFF")
    titulo.pack(pady=20)
    titulo.lift()  # Traer al frente

    frame = tk.Frame(menu, bg="#FFFFFF")
    frame.pack()
    frame.lift()  # Traer al frente

    estilo = {
        'font': ("Arial", 12),
        'bg': "#FFFFFF",
        'fg': "#22223B",
        'activebackground': "#9A8C98",
        'width': 30,
        'padx': 5,
        'pady': 5,
    }

    if rol in ["Administrador", "Vendedor"]:
        tk.Button(frame, text="Registrar Entrada", command=lambda: ventana_movimiento("entrada"), **estilo).pack(pady=5)
        tk.Button(frame, text="Registrar Salida", command=lambda: ventana_movimiento("salida"), **estilo).pack(pady=5)

    if rol == "Administrador":
        tk.Button(frame, text="Gestionar Usuarios", command=gestionar_usuarios, **estilo).pack(pady=5)

    tk.Button(frame, text="Consultar Inventario", command=consultar_inventario, **estilo).pack(pady=5)
    tk.Button(frame, text="Generar Reporte", command=ventana_exportar_reporte, **estilo).pack(pady=5)
    tk.Button(frame, text="Ver Alertas de Stock", command=lambda: mostrar_alertas_ventana(menu), **estilo).pack(pady=5)
    tk.Button(frame, text="Salir", command=menu.quit, **estilo).pack(pady=20)

    menu.mainloop()