import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="ues",
        password="123456",
        database="inventario_db"
    )