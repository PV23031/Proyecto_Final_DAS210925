from tkinter import messagebox

def validar_entero(valor):
    try:
        return int(valor)
    except ValueError:
        messagebox.showerror("Error", "Debes ingresar un número entero")
        return None
