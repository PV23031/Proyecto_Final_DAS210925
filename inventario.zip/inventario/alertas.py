from db import get_connection
import tkinter as tk
from tkinter import messagebox, ttk

def obtener_productos_bajo_stock(threshold=5):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT nombre, stock FROM productos WHERE stock < %s", (threshold,))
    resultados = cursor.fetchall()
    conn.close()
    return resultados

def mostrar_alertas_ventana(parent):
    productos_bajo = obtener_productos_bajo_stock()
    if productos_bajo:
        alerta = tk.Toplevel(parent)
        alerta.title("Productos con bajo stock")
        alerta.geometry("400x300")
        alerta.configure(bg="#FAF3E0")

        tk.Label(alerta, text="⚠️ Productos con bajo stock ⚠️", font=("Arial", 14, "bold"), bg="#FAF3E0", fg="#C44536").pack(pady=10)

        tabla = ttk.Treeview(alerta, columns=("Producto", "Stock"), show="headings")
        tabla.heading("Producto", text="Producto")
        tabla.heading("Stock", text="Stock")

        for nombre, stock in productos_bajo:
            tabla.insert("", "end", values=(nombre, stock))

        tabla.pack(padx=20, pady=10, fill="both", expand=True)
    else:
        messagebox.showinfo("Inventario", "Todos los productos están con stock adecuado.")